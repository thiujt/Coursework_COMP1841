<?php
if (isset($_POST['qtext'])){
    try {
        include 'includes/DatabaseConnection.php';
        include 'includes/DataBaseFunctions.php';

        insertPost($pdo, $_POST['qtext'],  $_FILES['fileToUpload']['name'], $_POST['users'],$_POST['modules']);
        include 'includes/uploadFile.php';
        header('location:posts.php');
    }catch(PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error:' . $e -> getMessage();
}
}else{
    include 'includes/DatabaseConnection.php';
    include 'includes/DataBaseFunctions.php';
    $title = 'Add a new question';
    $users = allUsers($pdo);
    $modules = allModules($pdo);
    ob_start();
    include 'templates/addpost.html.php';
    $output = ob_get_clean();
}
include 'templates/layout.html.php';
?>