<form action="" method="post">
    <input type="hidden" name="postid" value="<?=$post['id'];?>">
    <label for='qtext'>Edit your question here;</label>
    <textarea name="qtext" rows="3" cols="40">
    </textarea>

        <select name="modules">
        <option value="">Select a module</option>
        <?php foreach ($modules as $module):?>
            <option value="<?=htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <?=htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
            <?php endforeach;?>
        </select>

    <input type="submit" name="submit" value="Save">
    
    </form>
