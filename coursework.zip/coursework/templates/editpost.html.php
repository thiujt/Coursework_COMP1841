<form action="" method="post" enctype="multipart/form-data">
    <input type="hidden" name="postid" value="<?=$post['id'];?>">
    <label for='qtext'>Edit your question here</label>
    <input type="" name="qtext" value="<?=$post['qtext'];?>">
    <input type="file" name="fileToUpload">

    <?php $display_date = date('D d M Y', strtotime($post['qdate'])); ?>
    <?=htmlspecialchars($display_date, ENT_QUOTES, 'UTF-8')?>


    <select name="users">
        <option value="<?= htmlspecialchars($post['userid'], ENT_QUOTES, 'UTF-8'); ?>">
            <?= htmlspecialchars($post['username'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php foreach ($users as $user): ?>
            <option value="<?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach; ?>
    </select>


    <img height="100px" src="images/<?=htmlspecialchars($post['image'],ENT_QUOTES,'UTF-8');?>"/>


    <select name="modules">
        <option value="<?= htmlspecialchars($post['moduleid'], ENT_QUOTES, 'UTF-8'); ?>">
            <?= htmlspecialchars($post['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php foreach ($modules as $module): ?>
            <option value="<?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach; ?>
    </select>





    <input type="submit" name="submit" value="Save">
   
    </form>
