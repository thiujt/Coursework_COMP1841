<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="post.css">
    <title><?=$title?></title>
</head>
<body>
    <header><h1>Internet Post Database</h1></header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="posts.php">Post List</a></li>
            <li><a href="addpost.php">Add a new question</a></li>
            <li><a href="admin/login/login.html">Admin Login</a></li>
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    <footer> &copy; I Love GreenWich</footer>
</body>
</html>