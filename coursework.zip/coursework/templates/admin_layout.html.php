<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../post.css">
    <title><?=$title?></title>
</head>
<body>
    <header id="admin">
    <br>Internet Post Database Admin Area<br />
    Mange postes, modules and users</h1></header>
    <nav>
        <ul>
            <li><a href="posts.php">Post List</a></li>
            <li><a href="addpost.php">Add a new notification</a></li>
            <li><a href="usermanager/user.php">Manage User</a></li>
            <li><a href="login/logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    <footer> &copy; I Love GreenWich</footer>
</body>
</html>