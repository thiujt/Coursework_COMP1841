<?php
function query($pdo, $sql, $parameters=[]){
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}

function totalPosts($pdo){
    $query = query($pdo, 'SELECT COUNT(*) FROM post');
    $row = $query->fetch();
    return $row[0];
}

function getPost($pdo, $id) {
    $parameters = [':id' => $id];
    $query = query( $pdo,'SELECT 
                                post.*, 
                                user.name AS username, 
                                module.moduleName AS moduleName FROM post
                                INNER JOIN user ON post.userid = user.id
                                INNER JOIN module ON post.moduleid = module.id
                                WHERE post.id = :id',
                                $parameters);
                                return $query->fetch();
}

function updatePost($pdo, $postId, $qtext, $moduleid, $userid, $fileToUpload) {
    $query = 'UPDATE post SET qtext = :qtext, moduleid = :moduleid, userid = :userid, image = :fileToUpload WHERE id=:id';
    $parameters = [':qtext' => $qtext, ':id' => $postId, ':moduleid' => $moduleid, ':userid' => $userid, ':fileToUpload' => $fileToUpload];
    query($pdo, $query, $parameters);
} 

function deletePost($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM post WHERE id = :id', $parameters);
}

function allPosts($pdo) {
    $posts = query($pdo, 'SELECT 
    post.id,
    post.qtext,
    post.qdate,
    post.image,
    name,
    user.email,
    moduleName
    FROM post
    INNER JOIN user ON userid = user.id
    INNER JOIN module ON moduleid = module.id');
    return $posts->fetchAll();
}

function insertPost($pdo, $qtext,$fileToUpload, $userid, $moduleid) {
    $query = 'INSERT INTO post (qtext, qdate,`image`, userid, moduleid)
    VALUES (:qtext, CURDATE(),:fileToUpload, :userid, :moduleid)';
    $parameters = [':qtext'=> $qtext,':fileToUpload' => $fileToUpload, ':userid' => $userid, ':moduleid' => $moduleid];
    query($pdo, $query, $parameters);
}

function allUsers($pdo) {
    $users = query($pdo, 'SELECT * FROM user');
    return $users->fetchAll();
}

function allModules($pdo){
    $modules = query($pdo, 'SELECT * FROM module');
    return $modules->fetchAll();
}

function insertUser($pdo, $name, $email, $Password) {
    $query = 'INSERT INTO user (name, email, password)
    VALUES (:name, :email, :password)';
    $parameters = [':name' => $name, ':email' => $email, ':password' => $Password];
    query($pdo, $query, $parameters);
}

function deleteUser($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM user WHERE id = :id', $parameters);
}

function userHasPosts($pdo, $userId) {
    $sql = 'SELECT COUNT(*) FROM post WHERE userid = :userid';
    $parameters = [':userid' => $userId];
    $query = query($pdo, $sql, $parameters);
    $count = $query->fetchColumn();
    return $count > 0;
}