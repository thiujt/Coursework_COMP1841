<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="user.css">
    <title><?=$title?></title>
</head>
<body>
    <header id="admin">
    <br>User Manager Page</h1></header>
    <nav>
        <ul>
            <li><a href="adduser.php">Add user</a></li>
            <li><a href="../posts.php">Go Out</a></li>
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    <footer> &copy; I Love GreenWich</footer>
</body>
</html>