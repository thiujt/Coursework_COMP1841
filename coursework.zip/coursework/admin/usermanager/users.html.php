<table border='1px'>
    <tr>
        <th></th> <!-- This is for the serial number column -->
        <th>Name</th>
        <th>Email</th>
    </tr>
    <?php 
    $count = 1; // Initialize a count variable
    foreach($users as $user):  $userHasPosts = userHasPosts($pdo, $user['id']); // Assume this function checks if the user has posts
    ?>
    
        <tr>
            <td width="50px"><?= $count++; ?></td> <!-- Display the count number and then increment it -->
            <td width="300px"><?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8') ?></td>
            <td width="300px"><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?></td>
            <td>
            <?php if ($userHasPosts): ?>
                    <!-- If the user has posts, disable the delete button and show a message -->
                    <span>Cannot delete, user has post</span>
                <?php else: ?>
                <!-- Delete button inside the form -->
                <form action="deleteuser.php" method="post" onsubmit="return confirm('Are you sure you want to delete this user?');">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="submit" value="Delete">
                </form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>