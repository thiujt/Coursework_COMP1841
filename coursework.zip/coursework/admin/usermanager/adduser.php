<?php
if (isset($_POST['user'])){
    try {
        include '../../includes/DatabaseConnection.php';
        include '../../includes/DataBaseFunctions.php';

        insertUser($pdo, $_POST['user'], $_POST['email'], $_POST['password']);
        header('location:user.php');
    }catch(PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error:' . $e -> getMessage();
}
}else{
    include '../../includes/DatabaseConnection.php';
    include '../../includes/DataBaseFunctions.php';
    $title = 'Add user';
    $users = allUsers($pdo);
    ob_start();
    include 'adduser.html.php';
    $output = ob_get_clean();
}
include 'user_layout.html.php';
?>