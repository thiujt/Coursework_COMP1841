<?php
try {
    include '../../includes/DatabaseConnection.php';
    include '../../includes/DataBaseFunctions.php';

    $users = allUsers($pdo);
    $title = 'User list';

    ob_start();
    include 'users.html.php';
    $output = ob_get_clean();    
} catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Database error: ' . $e->getMessage();
}
include 'user_layout.html.php';
?>