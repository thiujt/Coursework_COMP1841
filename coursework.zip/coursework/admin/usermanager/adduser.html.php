<form action="adduser.php" method="post">
    <label for="user">Username:</label>
    <input type="text" name="user" id="user" required>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>

    <label for="password">Password:</label>
    <input type="password" name="password" id="password" required>

    <input type="submit" value="Add" class="btn add-btn">
    <input type="button" value="Back" class="btn back-btn" onclick="window.history.back();">
</form>