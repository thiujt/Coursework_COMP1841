
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Protected Page</title>
    <!-- Bootstrap CSS  -->
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <!-- Welcome Message -->
        <h1 class="display-4">Welcome to the Protected Page!</h1>
        <p class="lead">You are logged in and can access secure content.</p>

        <!-- Optional Alert (Success Message) -->
        <div class="alert alert-success" role="alert">
            You have successfully logged in. You can now view protected content.
        </div>

        <!-- Go to Posts Link -->
        <a href="../posts.php" class="btn btn-primary btn-lg">Go to Admin page</a>
    </div>
</body>
</html>