<?php
session_start();
if ($_SESSION["authorised"] != "Y"){
    header("Location: noauthorised.php");
}
?>