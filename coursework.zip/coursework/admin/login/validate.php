<?php
$ActualPassword = "secret";
$ActualUser = "thiujt";
if ($_POST["password"] == $ActualPassword && $_POST["username"] == $ActualUser )
{
    session_start();
    $_SESSION["authorised"] = "Y";
    header("Location:index.php");
} else {
    header("Location:wrongpassword.php");
}