<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied</title>
    <!-- Bootstrap CSS  -->
    <link href="../../css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex justify-content-center align-items-center" style="height: 100vh; background-color: #f8f9fa;">

    <div class="container text-center">
        <!-- Alert message for unauthorized access -->
        <div class="alert alert-danger" role="alert">
            Wrong information
        </div>
        <p>Please go to the <a href="login.html">Login Page</a> to access your account.</p>
    </div>

</body>
</html>