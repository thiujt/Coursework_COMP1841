<?php
include 'includes/DatabaseConnection.php';
include 'includes/DataBaseFunctions.php';
try{
    if(isset($_POST['qtext'])){
        updatePost($pdo, $_POST['postid'], $_POST['qtext'], $_POST['modules']);
        header('location:posts.php');
    }else{
        $post = getPost($pdo, $_GET['id']);
        $title = 'Edit post';
        $modules = allModules($pdo);

        ob_start();
        include 'templates/editpost.html.php';
        $output = ob_get_clean();
    }
}catch(PDOException $e){
    $title = 'error has occured';
    $output = 'Error editing post: ' . $e->getMessage();
}
include 'templates/layout.html.php';